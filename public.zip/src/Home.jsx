import React from 'react';
import data from '/Data';

const Home = () => {
  return (
    <div className="container mx-auto p-5">
     
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {data.map((e, i) => (



          <div key={i} className="bg-green-200 p-4 rounded-lg shadow-md text-center">
          

            <img src={e.img} alt={`Image of ${e.name}`} className="h-40 w-full object-cover rounded-md" />
            <h2 className="text-lg font-bold mt-2">{e.name}</h2>
            <p className="text-gray-500">{e.categories}</p>
            <p className="text-yellow-500">{e.value}</p>
            <p className="text-green-700 font-semibold">${e.price}</p>
          </div>



        ))}
      </div>
    </div>
  );
};

export default Home;
