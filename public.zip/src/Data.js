const data = [
    {
      img: "https://websitedemos.net/plant-store-02/wp-content/uploads/sites/410/2019/01/plant3-free-img.jpg",
      name: "Boncellensis Secullant",
      categories: "Plants",
      value: "5 star",
      price: 20, 
    },
    {
      img: "https://websitedemos.net/plant-store-02/wp-content/uploads/sites/410/2019/01/cactus2-free-img.jpg",
      name: "Cleistocactus",
      categories: "Cactus",
      value: "5 star",
      price: 25, 
    },
    {
      img: "https://websitedemos.net/plant-store-02/wp-content/uploads/sites/410/2019/01/plant5-free-img.jpg",
      name: "Green Soil Lotus",
      categories: "Plants",
      value: "5 star",
      price: 34, 
    },
    {
      img: "https://websitedemos.net/plant-store-02/wp-content/uploads/sites/410/2019/01/plant1-free-img.jpg",
      name: "Money Plant",
      categories: "Plants",
      value: "5 star",
      price: 20, 
    },
    {
      img: "https://websitedemos.net/plant-store-02/wp-content/uploads/sites/410/2019/01/cactus4-free-img.jpg",
      name: "Old Lady Cactus",
      categories: "Plants",
      value: "5 star",
      price: 12, 
    },
    {
      img: "https://websitedemos.net/plant-store-02/wp-content/uploads/sites/410/2019/01/plant4-free-img.jpg",
      name: "Piorro Quisquam",
      categories: "Plants",
      value: "5 star",
      price: 54, 
    },
    {
      img: "https://websitedemos.net/plant-store-02/wp-content/uploads/sites/410/2019/01/cactus6-free-img.jpg",
      name: "Rattle Snake Tail",
      categories: "Plants",
      value: "5 star",
      price: 74, 
    },
    {
      img: "https://websitedemos.net/plant-store-02/wp-content/uploads/sites/410/2019/01/plant6-free-img.jpg",
      name: "Star Cactus",
      categories: "Plants",
      value: "5 star",
      price: 30, 
    },
  ];
  
  export default data;
  