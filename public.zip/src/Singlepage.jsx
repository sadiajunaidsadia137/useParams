import React from 'react'

const Singlepage = () => {
  return (
    <div>Singlepage</div>
  )
}

export default Singlepage